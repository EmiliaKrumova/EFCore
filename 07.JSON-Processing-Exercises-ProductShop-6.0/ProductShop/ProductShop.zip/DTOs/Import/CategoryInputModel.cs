﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductShop.DTOs.Import
{
    public class CategoryInputModel
    {
        public string? Name { get; set; }
    }
}
