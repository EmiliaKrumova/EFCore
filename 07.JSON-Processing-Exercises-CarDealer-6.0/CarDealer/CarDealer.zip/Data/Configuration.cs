﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-8Q2KJ1F\SQLEXPRESS;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}
