﻿namespace P02_FootballBetting
{
    using System;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.EntityFrameworkCore;
    using P02_FootballBetting.Data;
    public class StartUp
    {
        static void Main(string[] args)
        {
           
        }
    }
}
