﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-8Q2KJ1F\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
