﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-8Q2KJ1F\SQLEXPRESS;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
